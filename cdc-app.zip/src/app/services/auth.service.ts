import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private baseUrl: string = 'http://localhost:8080';

  constructor(private http: HttpClient) { }

  /***** Login User *****/
  login(objUser: any): Observable<HttpResponse<any>> {
    let URL = this.baseUrl + '/user';
    console.log(URL);
    return this.http.post<any>(URL, objUser, { observe: 'response' });
  }
}
