import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-qsn',
  templateUrl: './manage-qsn.page.html',
  styleUrls: ['./manage-qsn.page.scss'],
})
export class ManageQsnPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
