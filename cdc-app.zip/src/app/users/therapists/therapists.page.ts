import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-therapists',
  templateUrl: './therapists.page.html',
  styleUrls: ['./therapists.page.scss'],
})
export class TherapistsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
