import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-therapists',
  templateUrl: './update-therapists.page.html',
  styleUrls: ['./update-therapists.page.scss'],
})
export class UpdateTherapistsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
