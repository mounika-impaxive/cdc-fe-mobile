import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-therapy',
  templateUrl: './therapy.page.html',
  styleUrls: ['./therapy.page.scss'],
})
export class TherapyPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
