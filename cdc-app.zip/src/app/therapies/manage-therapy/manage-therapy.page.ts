import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-therapy',
  templateUrl: './manage-therapy.page.html',
  styleUrls: ['./manage-therapy.page.scss'],
})
export class ManageTherapyPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
