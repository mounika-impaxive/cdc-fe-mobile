import { Component, OnInit } from '@angular/core';
import * as EventEmitter from 'events';
import { IonicSelectableComponent } from 'ionic-selectable';

class Port {
  public id: number;
  public name: string;
}

@Component({
  selector: 'app-goals',
  templateUrl: './goals.page.html',
  styleUrls: ['./goals.page.scss'],
})
export class GoalsPage implements OnInit {

  ports: Port[];
  port: Port;
  milestone = false;
  mileInfo = [{
    "id": 1,
    "milestone_title": "",
    "start_date": "",
    "target_date": ""
  }]

  constructor() {
    this.ports = [
      { id: 1, name: 'Student 1' },
      { id: 2, name: 'Student 2' },
      { id: 3, name: 'Student 3' }
    ];
  }

  ngOnInit() {
  }

  portChange(event: {
    component: IonicSelectableComponent,
    value: any
  }) {
    console.log('port:', event.value);
  }

  showMile(){
    this.milestone = true;
  }

  clearMile(){
    this.milestone = false;
  }

  addMile(){
    this.mileInfo.push({
      "id": this.mileInfo.length+1,
      "milestone_title": "",
      "start_date": "",
      "target_date": ""
    })
  }

  removeMile(index){
    this.mileInfo.splice(index, 1);
  }

}
