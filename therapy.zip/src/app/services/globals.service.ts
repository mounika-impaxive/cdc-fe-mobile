import { Injectable } from '@angular/core';
import { LoadingController, ToastController, AlertController } from '@ionic/angular';
import { Storage } from '@ionic/storage';

@Injectable({
  providedIn: 'root'
})
export class GlobalsService {

  loader:HTMLIonLoadingElement;
  Role;

  constructor(public loadingController: LoadingController, private storage:Storage) {
    this.storage.get('role').then((val)=>{
      console.log(val);
      this.Role = val;
    });
  }

  showLoading() {
    this.loadingController.create({
      message: "Loadng..."
    }).then((loading) => {
      loading.present();
    })
  }

  async hideLoading() {
    const element = await this.loadingController.getTop();
      if(element){
        await this.loadingController.dismiss();
      }
  }
}
