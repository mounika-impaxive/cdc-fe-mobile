import { Component, OnInit } from '@angular/core';
import { ActionSheetController } from '@ionic/angular';

@Component({
  selector: 'app-manage-therapists',
  templateUrl: './manage-therapists.page.html',
  styleUrls: ['./manage-therapists.page.scss'],
})
export class ManageTherapistsPage implements OnInit {

  constructor(public actionSheetController: ActionSheetController) { }

  ngOnInit() {
  }

  async presentActionSheet() {
    const actionSheet = await this.actionSheetController.create({
      cssClass: 'my-custom-class',
      mode: 'ios',
      buttons: [{
        text: 'View',
        icon: '',
        handler: () => {
          console.log('View clicked');
        }
      }, {
        text: 'Edit',
        icon: '',
        handler: () => {
          console.log('Edit clicked');
        }
      }, {
        text: 'Delete',
        role: 'destructive',
        icon: '',
        handler: () => {
          console.log('Delete clicked');
        }
      }, {
        text: 'Cancel',
        icon: 'close',
        role: 'cancel',
        handler: () => {
          console.log('Cancel clicked');
        }
      }]
    });
    await actionSheet.present();
  }

}
