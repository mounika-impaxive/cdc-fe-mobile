import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-children',
  templateUrl: './manage-children.page.html',
  styleUrls: ['./manage-children.page.scss'],
})
export class ManageChildrenPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
