import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-goals',
  templateUrl: './manage-goals.page.html',
  styleUrls: ['./manage-goals.page.scss'],
})
export class ManageGoalsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
