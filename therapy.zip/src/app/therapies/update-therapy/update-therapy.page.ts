import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-therapy',
  templateUrl: './update-therapy.page.html',
  styleUrls: ['./update-therapy.page.scss'],
})
export class UpdateTherapyPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
