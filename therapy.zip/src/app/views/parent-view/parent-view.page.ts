import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parent-view',
  templateUrl: './parent-view.page.html',
  styleUrls: ['./parent-view.page.scss'],
})
export class ParentViewPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
