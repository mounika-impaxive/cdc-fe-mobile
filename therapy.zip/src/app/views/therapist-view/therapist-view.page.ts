import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-therapist-view',
  templateUrl: './therapist-view.page.html',
  styleUrls: ['./therapist-view.page.scss'],
})
export class TherapistViewPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
