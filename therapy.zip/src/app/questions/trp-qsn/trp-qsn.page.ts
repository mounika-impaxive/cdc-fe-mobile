import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-trp-qsn',
  templateUrl: './trp-qsn.page.html',
  styleUrls: ['./trp-qsn.page.scss'],
})
export class TrpQsnPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
