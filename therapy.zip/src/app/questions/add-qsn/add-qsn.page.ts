import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-qsn',
  templateUrl: './add-qsn.page.html',
  styleUrls: ['./add-qsn.page.scss'],
})
export class AddQsnPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
